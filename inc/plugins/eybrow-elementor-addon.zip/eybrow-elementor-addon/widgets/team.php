<?php
class eybrow_team_widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'team_widget';
	}

	public function get_title()
	{
		return esc_html__('Team', 'eybrow');
	}

	public function get_icon()
	{
		return 'eicon-user-circle-o';
	}

	public function get_categories()
	{
		return ['eybrow-elementor-addon'];
	}

	public function get_keywords()
	{
		return ['Team', 'Teams'];
	}

	protected function register_controls()
	{
    // Content Section

    $this->start_controls_section(
        'content_section',
        [
            'label' => esc_html__('Content', 'elementor-currency-control'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );
	$this->add_control(
		'team_image',
		[
			'label' => esc_html__( 'Choose Image', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::MEDIA,
			'default' => [
				'url' => \Elementor\Utils::get_placeholder_image_src(),
			],
		]
	);

	$this->add_control(
		'team_title',
		[
			'label' => esc_html__( 'Title', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Emma Johnson', 'eybrow' ),
			'placeholder' => esc_html__( 'Type your title here', 'eybrow' ),
			'label_block' => true,
		]
	);

	$this->add_control(
		'team_sub_title',
		[
			'label' => esc_html__( 'Sub Title', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( '(Founder)', 'eybrow' ),
			'placeholder' => esc_html__( 'Type your title here', 'eybrow' ),
			'label_block' => true,
		]
	);
	
	$repeater = new \Elementor\Repeater();

	$repeater->add_control(
		'list_title',
		[
			'label' => esc_html__( 'Title', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Facebook' , 'eybrow' ),
			'label_block' => true,
		]
	);

	$repeater->add_control(
		'team_social_icon',
		[
			'label' => esc_html__( 'Social Icons', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::ICON,
			'label_block' => true,
			'include' => [
				'fa fa-facebook',
				'fa fa-flickr',
				'fa fa-google-plus',
				'fa fa-instagram',
				'fa fa-linkedin',
				'fa fa-pinterest',
				'fa fa-reddit',
				'fa fa-twitch',
				'fa fa-twitter',
				'fa fa-vimeo',
				'fa fa-youtube',
			],
			'default' => 'fa fa-facebook',
		]
	);
	
	$repeater->add_control(
		'team_social_url',
		[
			'label' => esc_html__( 'Social Links', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::URL,
			'options' => [ 'url', 'is_external', 'nofollow' ],
			'default' => [
				'url' => '',
				'is_external' => true,
				'nofollow' => true,
				// 'custom_attributes' => '',
			],
			'label_block' => true,
		]
	);

	$this->add_control(
		'team_social_list',
		[
			'label' => esc_html__( 'Social List', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::REPEATER,
			'fields' => $repeater->get_controls(),
			'default' => [
				[
					'list_title' => esc_html__( 'Facebook', 'eybrow' ),
				],
				[
					'list_title' => esc_html__( 'Twitter', 'eybrow' ),
				],
			],
			'title_field' => '{{{ list_title }}}',
		]
	);



    $this->end_controls_section();
	
	$this->start_controls_section(
		'style_section',
		[
			'label' => esc_html__( 'Style', 'eybrow' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

	



    $this->end_controls_section();
    }


	protected function render(){
    $settings = $this->get_settings_for_display();
    $team_image = $settings['team_image'];
    $team_title = $settings['team_title'];
    $team_sub_title = $settings['team_sub_title'];
    $team_social_list = $settings['team_social_list'];
   ?>
	<div class="team-item">
		<div class="team-image">
			<figure class="hover-anime">
				<img src="<?php echo $team_image['url']; ?>" alt="">
			</figure>
		</div>

		<div class="team-info">
			<h3><?php echo $team_title; ?></h3>
			<p><?php echo $team_sub_title; ?></p>
			<div class="team-social-links">
				<ul>
					<?php 
					foreach ($team_social_list as $social){
						?>
							<li><a href="<?php echo $social['team_social_url']['url']; ?>"><i class="<?php echo $social['team_social_icon']; ?>"></i></a></li>
						<?php
					}
					?>
				</ul>
			</div>
		</div>
	</div>
    <?php
}
}
