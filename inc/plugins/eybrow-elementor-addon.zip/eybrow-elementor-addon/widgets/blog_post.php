<?php
class eybrow_blog_widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'blog_widget';
	}

	public function get_title()
	{
		return esc_html__('Blog Post', 'eybrow');
	}

	public function get_icon()
	{
		return 'eicon-posts-grid';
	}

	public function get_categories()
	{
		return ['eybrow-elementor-addon'];
	}

	public function get_keywords()
	{
		return ['Blog', 'Post'];
	}

	protected function register_controls()
	{
    // Content Section

    $this->start_controls_section(
        'content_section',
        [
            'label' => esc_html__('Content', 'elementor-currency-control'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->end_controls_section();
	
	$this->start_controls_section(
		'style_section',
		[
			'label' => esc_html__( 'Style', 'eybrow' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

	



    $this->end_controls_section();
    }


	protected function render(){
    $settings = $this->get_settings_for_display();

	?>
		<div class="container">
			<div class="row">
				<?php 
                   $args = array(
                    'post_type' => 'post',
                    'posts_per_page' => 3,
                    );
                     $query = new WP_Query( $args );
                
                    if ($query-> have_posts() ) : 
                    while($query-> have_posts()  ) : $query-> the_post();
                    ?>
				<div class="col-lg-4">
					<!-- Post Item Start -->
					<div class="post-item wow fadeInUp">
						<!-- Post Featured Image Start -->
						<div class="post-featured-image">
							<a href="<?php the_permalink(); ?>">
								<figure class="hover-anime">
									<img src="<?php the_post_thumbnail_url(); ?>" alt="">
								</figure>
							</a>
						</div>
						<!-- Post Featured Image End -->

						<!-- Post Header Start -->
						<div class="post-header">
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<div class="post-meta">
								<ul>
									<li><?php echo get_the_date(); ?></li>
								</ul>
							</div>
						</div>
						<!-- Post Header End -->

						<!-- Post Read More Button Start -->
						<div class="post-readmore">
							<a href="<?php the_permalink(); ?>"><img src="<?php echo get_template_directory_uri(  ). '/images/icon-readmore.svg'?>" alt=""></a>
                            
						</div>
						<!-- Post Read More Button End -->
					</div>
					<!-- Post Item End -->
				</div>
				<?php
					endwhile; else: _e('No post found' ,'oredoo');
					endif;
					wp_reset_postdata();
				?>
			</div>
		</div>
	<?php
}
}
