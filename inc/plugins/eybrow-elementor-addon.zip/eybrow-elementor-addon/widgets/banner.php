<?php
class eybrow_banner_widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'banner_widget';
	}

	public function get_title()
	{
		return esc_html__('Banner', 'eybrow');
	}

	public function get_icon()
	{
		return 'eicon-banner';
	}

	public function get_categories()
	{
		return ['eybrow-elementor-addon'];
	}

	public function get_keywords()
	{
		return ['Banner', 'CTA'];
	}

	protected function register_controls()
	{
    // Content Section

    $this->start_controls_section(
        'content_section',
        [
            'label' => esc_html__('Content', 'elementor-currency-control'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );
	$this->add_control(
		'banner_image',
		[
			'label' => esc_html__( 'Choose Image', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::MEDIA,
			'default' => [
				'url' => \Elementor\Utils::get_placeholder_image_src(),
			],
		]
	);

	$this->add_control(
		'banner_title',
		[
			'label' => esc_html__( 'Title', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Hair Cut', 'eybrow' ),
			'placeholder' => esc_html__( 'Type your title here', 'eybrow' ),
			'label_block' => true,
		]
	);

	$this->add_control(
		'banner_description',
		[
			'label' => esc_html__( 'Sub Title', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::TEXTAREA,
			'default' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the.', 'eybrow' ),
			'placeholder' => esc_html__( 'Type your title here', 'eybrow' ),
			'label_block' => true,
		]
	);

	$this->add_control(
		'banner_button_text',
		[
			'label' => esc_html__( 'Button', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Get Now', 'eybrow' ),
			'placeholder' => esc_html__( 'Type your title here', 'eybrow' ),
			'label_block' => true,
		]
	);
	$this->add_control(
		'banner_button_url',
		[
			'label' => esc_html__( 'Button URL', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::URL,
			'options' => [ 'url', 'is_external', 'nofollow' ],
			'default' => [
				'url' => '',
				'is_external' => true,
				'nofollow' => true,
				// 'custom_attributes' => '',
			],
			'label_block' => true,
		]
	);
	

    $this->end_controls_section();
	
	$this->start_controls_section(
		'style_section',
		[
			'label' => esc_html__( 'Style', 'eybrow' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

	



    $this->end_controls_section();
    }


	protected function render(){
    $settings = $this->get_settings_for_display();
    $banner_image = $settings['banner_image'];
    $banner_title = $settings['banner_title'];
    $banner_description = $settings['banner_description'];
    $banner_button_text = $settings['banner_button_text'];
    $banner_button_url = $settings['banner_button_url'];
   ?>
	<div class="gift-box">
		<div class="gift-content wow fadeInUp" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
			<h3><?php echo $banner_title; ?></h3>
			<p><?php echo $banner_description; ?></p>
			<a href="<?php echo $banner_button_url ['url']; ?>" class="btn-default"><?php echo $banner_button_text; ?></a>
		</div>

		<div class="gift-image wow fadeInUp" data-wow-delay="0.75s" style="visibility: visible; animation-delay: 0.75s; animation-name: fadeInUp;">
			<img src="<?php echo $banner_image ['url']; ?>" alt="">
		</div>
	</div>
    <?php
}
}
