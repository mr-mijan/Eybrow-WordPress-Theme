<?php
class eybrow_heading_widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'heading_widget';
	}

	public function get_title()
	{
		return esc_html__('Heading', 'eybrow');
	}

	public function get_icon()
	{
		return 'eicon-heading';
	}

	public function get_categories()
	{
		return ['eybrow-elementor-addon'];
	}

	public function get_keywords()
	{
		return ['Heading', 'Headline'];
	}

	protected function register_controls()
	{
    // Content Section

    $this->start_controls_section(
        'content_section',
        [
            'label' => esc_html__('Content', 'elementor-currency-control'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

	$this->add_control(
		'heading_sub_title',
		[
			'label' => esc_html__( 'Sub Title', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Default title', 'eybrow' ),
			'placeholder' => esc_html__( 'Type your title here', 'eybrow' ),
			'label_block' => true,
		]
	);

	$this->add_control(
		'heading_title',
		[
			'label' => esc_html__( 'Title', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Default title', 'eybrow' ),
			'placeholder' => esc_html__( 'Type your title here', 'eybrow' ),
			'label_block' => true,
		]
	);


    $this->end_controls_section();
	
	$this->start_controls_section(
		'style_section',
		[
			'label' => esc_html__( 'Style', 'eybrow' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

	$this->add_control(
		'heading_text_align',
		[
			'label' => esc_html__( 'Alignment', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::CHOOSE,
			'options' => [
				'left' => [
					'title' => esc_html__( 'Left', 'eybrow' ),
					'icon' => 'eicon-text-align-left',
				],
				'center' => [
					'title' => esc_html__( 'Center', 'eybrow' ),
					'icon' => 'eicon-text-align-center',
				],
				'right' => [
					'title' => esc_html__( 'Right', 'eybrow' ),
					'icon' => 'eicon-text-align-right',
				],
			],
			'default' => 'center',
			'toggle' => true,
			'selectors' => [
				'{{WRAPPER}} .section-title' => 'text-align: {{VALUE}};',
			],
		]
	);

	$this->add_control(
		'heading_margin',
		[
			'label' => esc_html__( 'Margin', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
			'default' => [
				'top' => 0,
				'right' => 0,
				'bottom' => 80,
				'left' => 0,
				'unit' => 'px',
				'isLinked' => false,
			],
			'selectors' => [
				'{{WRAPPER}} .section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
	);

	$this->add_control(
		'heading_sub_options',
		[
			'label' => esc_html__( 'Sub Title', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::HEADING,
			'separator' => 'after',
		]
	);

	$this->add_control(
		'heading_sutitle_color',
		[
			'label' => esc_html__( 'Subtitle Color', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .section-title h3' => 'color: {{VALUE}}',
			],
		]
	);

	$this->add_group_control(
		\Elementor\Group_Control_Typography::get_type(),
		[
			'name' => 'subtitle_typography',
			'selector' => '{{WRAPPER}} .section-title h3',
		]
	);
	$this->add_control(
		'sbutitle_animation',
		[
			'label' => esc_html__( 'Height', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%', 'em' ],
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 1000,
					'step' => 1,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'default' => [
				'unit' => 'px',
				'size' => 26,
			],
			'selectors' => [
				'{{WRAPPER}} .section-title h3:before' => 'height: {{SIZE}}{{UNIT}};',
			],
		]
	);

	$this->add_control(
		'heading_title_options',
		[
			'label' => esc_html__( 'Title', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::HEADING,
			'separator' => 'after',
		]
	);
	$this->add_control(
		'heading_title_color',
		[
			'label' => esc_html__( 'Title Color', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .section-title h2' => 'color: {{VALUE}}',
			],
		]
	);

	$this->add_group_control(
		\Elementor\Group_Control_Typography::get_type(),
		[
			'name' => 'title_typography',
			'selector' => '{{WRAPPER}} .section-title h2',
		]
	);
	
    $this->end_controls_section();


    }


	protected function render(){
    $settings = $this->get_settings_for_display();
    $heading_sub_title = $settings['heading_sub_title'];
    $heading_title = $settings['heading_title'];
   ?>
    <!-- Section Title Start -->
    <div class="section-title">
        <h3 class="wow fadeInUp"><?php echo $heading_sub_title; ?></h3>
        <h2 class="wow fadeInUp"><?php echo $heading_title; ?></h2>
    </div>
    <!-- Section Title End -->
    <?php
}
}
