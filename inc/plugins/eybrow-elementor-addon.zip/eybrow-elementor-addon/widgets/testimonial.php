<?php
class eybrow_testimonial_widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'testimonial_widget';
	}

	public function get_title()
	{
		return esc_html__('Testimonialost', 'eybrow');
	}

	public function get_icon()
	{
		return 'icon-testimonial';
	}

	public function get_categories()
	{
		return ['eybrow-elementor-addon'];
	}

	public function get_keywords()
	{
		return ['Testimonial', 'Reviews'];
	}

	protected function register_controls()
	{
    // Content Section

    $this->start_controls_section(
        'content_section',
        [
            'label' => esc_html__('Content', 'elementor-currency-control'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

	$repeater = new \Elementor\Repeater();

	$repeater->add_control(
		'testimonial_title',
		[
			'label' => esc_html__( 'Title', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'List Title' , 'eybrow' ),
			'label_block' => true,
		]
	);

	$repeater->add_control(
		'testimonial_content',
		[
			'label' => esc_html__( 'Content', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::WYSIWYG,
			'default' => esc_html__( 'List Content' , 'eybrow' ),
			'show_label' => false,
		]
	);

	$repeater->add_control(
		'testimonial_image',
		[
			'label' => esc_html__( 'Client Image', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::MEDIA,
			'default' => [
				'url' => \Elementor\Utils::get_placeholder_image_src(),
			],
		]
	);

	$this->add_control(
		'testimonials',
		[
			'label' => esc_html__( 'Testimonial List', 'eybrow' ),
			'type' => \Elementor\Controls_Manager::REPEATER,
			'fields' => $repeater->get_controls(),
			'default' => [
				[
					'testimonial_title' => esc_html__( 'Title #1', 'eybrow' ),
					'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'eybrow' ),
				],
				[
					'testimonial_title' => esc_html__( 'Title #2', 'eybrow' ),
					'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'eybrow' ),
				],
			],
			'title_field' => '{{{ testimonial_title }}}',
		]
	);

    $this->end_controls_section();
	
	$this->start_controls_section(
		'style_section',
		[
			'label' => esc_html__( 'Style', 'eybrow' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

	



    $this->end_controls_section();
    }


	protected function render(){
    $settings = $this->get_settings_for_display();
	$testimonials = $settings['testimonials'];

	?>
		<!-- Testimonial Carousel Start -->
		<div class="testimonial-carousel">
			<div class="swiper">
				<div class="swiper-wrapper">
				<?php 
					foreach ($testimonials as $testimonial){
						?>
						<!-- Testimonial Slide Start -->
						<div class="swiper-slide">
							<div class="testimonial-slide">
								<div class="testimonial-header">
									<div class="author-img">
										<img src="<?php echo $testimonial['testimonial_image']['url']; ?>" alt="">
									</div>

									<div class="author-info">
										<h3><?php echo $testimonial['testimonial_title']; ?></h3>
									</div>
								</div>

								<div class="testimonial-content">
									<p><?php echo $testimonial['testimonial_content']; ?></p>
								</div>
							</div>
						</div>
						<!-- Testimonial Slide End -->						
					<?php
					}
					?>               
				</div>
				
				<div class="swiper-pagination"></div>
			</div>						
		</div>
		<!-- Testimonial Carousel End -->
	<?php
}
}
